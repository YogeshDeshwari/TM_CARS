Ford Transit SSV
___________________________________________________________________________________________________________________________________________________________________

Original Author: Turn 10 Studios (Forza 4)

Rip model, UVs, some texture workflow & TMUF export: GKRacer

Too much drift cars & big-displacement GTs...Utilitary vehicles FTW :fum

Enjoy ;D