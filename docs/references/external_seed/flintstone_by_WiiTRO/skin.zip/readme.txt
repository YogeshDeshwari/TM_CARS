

The Flintstone Car



�***************************************************�

- Original author : Just Speeding (justspeeding@hotmail.com)


�***************************************************�

- updated for Trackmania Forever by : Just Speeding


�***************************************************�

Instal :

put the zip file into :

...\My documents\TrackMania\Skins\Vehicles\CarCommon

�***************************************************�

  available on carpark : http://www.trackmania-carpark.com/


have fun!!!!!!!!!!!!


Yabedabedooooooooooooooooooooooooooooooooooooooooooooooooooooooo
